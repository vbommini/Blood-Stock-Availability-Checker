import tkinter as tk
from tkinter import ttk,Button
from data.availability import bloodAvailability

style = ttk.Style()
style.configure('Custom.Label',background= "white")

def request(frame):
    root = tk.Toplevel()
    root.title("Request Form")
    root.configure(bg='white')

    # Create a frame to hold the form elements
    form_frame = tk.Frame(root,bg="white")
    form_frame.pack(padx=10, pady=10)

    # Create the form elements
    name_label = tk.Label(form_frame, text="Name:",bg="white", font=("Arial", 14))
    name_label.grid(row=0, column=0, padx=5, pady=5)

    name_entry = tk.Entry(form_frame)
    name_entry.grid(row=0, column=1, padx=5, pady=5)

    number_label = tk.Label(form_frame, text="Contact Number:",bg="white", font=("Arial", 14))
    number_label.grid(row=1, column=0, padx=5, pady=5)

    number_entry = tk.Entry(form_frame)
    number_entry.grid(row=1, column=1, padx=5, pady=5)

    location_label = tk.Label(form_frame, text="Location:",bg="white", font=("Arial", 14))
    location_label.grid(row=2, column=0, padx=5, pady=5)

    location_entry = tk.Entry(form_frame)
    location_entry.grid(row=2, column=1, padx=5, pady=5)

    blood_group_label = tk.Label(form_frame, text="Blood Group:",bg="white", font=("Arial", 14))
    blood_group_label.grid(row=3, column=0, padx=5, pady=5)

    blood_group_entry = tk.Entry(form_frame)
    blood_group_entry.grid(row=3, column=1, padx=5, pady=5)

    num_units_label = tk.Label(form_frame, text="Number of Units Required:",bg="white", font=("Arial", 14))
    num_units_label.grid(row=4, column=0, padx=5, pady=5)

    num_units_entry = tk.Entry(form_frame)
    num_units_entry.grid(row=4, column=1, padx=5, pady=5)

    submit_button = tk.Button(form_frame, text="Submit",fg="white",bg="#1c72eb", command=lambda: root.destroy())
    submit_button.grid(row=5, column=1, padx=5, pady=5)



class availabilityFrame:
    def load(root,frame,location,bloodGroup):
        #values
        availability = str(bloodAvailability().get_availability(location,bloodGroup))
        for widget in frame.winfo_children():
            widget.destroy()
        
        # create a table with columns "Location", "bloodGroup" and "Availability" inside the frame
        location_column = ttk.Label(frame, text="Location",style="Custom.Label")
        location_column.grid(row=0, column=0, padx=10, pady=10)

        location_column = ttk.Label(frame, text="Blood Group",style="Custom.Label")
        location_column.grid(row=0, column=1, padx=10, pady=10)

        availability_column = ttk.Label(frame, text="Availability",style="Custom.Label")
        availability_column.grid(row=0, column=2, padx=10, pady=10)

        l = ttk.Label(frame, text=location,style="Custom.Label", font=("Arial", 12))
        l.grid(row=1, column=0, padx=10, pady=10)

        b = ttk.Label(frame, text=bloodGroup,style="Custom.Label", font=("Arial", 12))
        b.grid(row=1, column=1, padx=10, pady=10)

        a = ttk.Label(frame, text=availability,style="Custom.Label", font=("Arial", 12))
        a.grid(row=1, column=2, padx=10, pady=10)

        r = Button(frame,text="Request", fg="white", bg="#1c72eb", command=lambda: request(frame) )
        if(availability == '0'):
            r.grid(row = 1,column=3, padx=10, pady=10)
        else:
            r.destroy()

        root.update()