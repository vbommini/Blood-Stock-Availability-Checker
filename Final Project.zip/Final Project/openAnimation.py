from PIL import Image, ImageTk
import tkinter as tk

from selectPage import selectOptions

class Loading:

    def load(root):
        # load and resize image
        image = Image.open("blood_drop.png")
        width, height = 300,384
        new_width = 30
        new_height = int((height / width) * new_width)
        resized_image = image.resize((new_width, new_height))
        tkimage = ImageTk.PhotoImage(resized_image)

        # create label to display image
        label = tk.Label(root, image=tkimage)
        label.pack(fill="both", expand=True)

        # hide the label
        label.place(relx=0.5, rely=0.5, anchor="center")
        label.lower()

        # function to animate the label
        def animate():
            label.scale += 0.01
            if label.scale <= 1:
                new_width = int(width * label.scale)
                new_height = int(height * label.scale)
                resized_image = image.resize((new_width, new_height))
                tkimage = ImageTk.PhotoImage(resized_image)
                label.configure(image=tkimage)
                label.image = tkimage
                label.place_configure(relx=0.5, rely=0.5, anchor="center")
                label.lift()
                label.after(3, animate)
            else:
                # remove everything from the screen
                label.destroy()

                selectOptions().load(root=root)

        # set initial scale value and run the animation
        label.scale = 0.1
        animate()