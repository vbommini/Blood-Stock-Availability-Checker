class bloodAvailability:
    availability = {
        "Houghton" : {
            "A+" : 0,
            "A-" : 2,
            "B+" : 3,
            "B-" : 4,
            "O+" : 5,
            "O-" : 6,
            "AB+" : 7,
            "AB-" : 8,
            "SelectGroup" :0
        }, 
        "Marquette" : {
            "A+" : 9,
            "A-" : 10,
            "B+" : 11,
            "B-" : 12,
            "O+" : 13,
            "O-" : 14,
            "AB+" : 15,
            "AB-" : 16,
            "SelectGroup" :0
        }, 
        "Iron Mountain" : {
            "A+" : 17,
            "A-" : 18,
            "B+" : 19,
            "B-" : 20,
            "O+" : 21,
            "O-" : 22,
            "AB+" : 23,
            "AB-" : 24,
            "SelectGroup" :0
        }, 
        "Appleton" : {
            "A+" : 25,
            "A-" : 26,
            "B+" : 27,
            "B-" : 28,
            "O+" : 29,
            "O-" : 30,
            "AB+" : 31,
            "AB-" : 32,
            "SelectGroup" :0
        }
    }
    
    def get_availability(self,location,bloodGroup):
        return self.availability[location][bloodGroup]
