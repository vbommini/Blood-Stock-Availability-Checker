import tkinter as tk
from tkinter import ttk
from PIL import Image,ImageTk
from registrationForm import RegistrationForm
import pandas as pd

def register(root):
    RegistrationForm(root)

def Login(root,username_entry,password_entry,login_status_label,login_frame,image_label):
    df = pd.read_csv('users.csv')
    df = df.astype(str)

    userName = username_entry.get()
    password = password_entry.get()
    if(df['userName'].isin([userName]).any() and df['password'].isin([password]).any()):
        login_status_label.config(text="login Success", fg="green")
        image_label.destroy()
        #import next step
        from selectPage import selectOptions
        
        login_status_label.after(3,lambda: selectOptions().load(root=root,login_frame= login_frame))
    else:
        login_status_label.config(text="user name or password is incorrect", fg="red")
    

root = tk.Tk()
root.geometry('600x500')
root.title('Login Screen')
root.configure(bg='white')

# load and resize image
image = Image.open("images/blood_drop.png")
width, height = 300,384
new_width = 30
new_height = int((height / width) * new_width)
resized_image = image.resize((new_width, new_height))
tkimage = ImageTk.PhotoImage(resized_image)

# Load the image
logo = Image.open('images/blood-donation-png.png')
logo = ImageTk.PhotoImage(logo)

# Draw the user logo image on the circle
user_logo_img = Image.open('images/userLogo.png')
user_logo_img = ImageTk.PhotoImage(user_logo_img)

# create label to display image
label = tk.Label(root,image = tkimage, bg="white")
label.pack(fill="both", expand=True)

# hide the label
label.place(relx=0.5, rely=0.5, anchor="center")
label.lower()

# function to animate the label
def animate():
    label.scale += 0.01
    if label.scale <= 1:
        new_width = int(width * label.scale)
        new_height = int(height * label.scale)
        resized_image = image.resize((new_width, new_height))
        tkimage = ImageTk.PhotoImage(resized_image)
        label.configure(image = tkimage)
        label.image = tkimage
        label.place_configure(relx=0.5, rely=0.5, anchor="center")
        label.lift()
        label.after(3, animate)
    else:
        # remove everything from the screen
        label.destroy()
        root.update()

        # Create a Label widget for the image
        image_label = tk.Label(root, image=logo, bg='white')
        image_label.pack(side=tk.LEFT, padx=20)

        # Create a Frame widget for the login form
        # Create a custom style for the frame
        style = ttk.Style()
        style.configure('Custom.TFrame', foreground='black', background='white')

        login_frame = ttk.Frame(root, padding=20, style='Custom.TFrame')
        login_frame.pack(side=tk.LEFT)

        # Create a Label widget for the user logo
        user_logo = tk.Canvas(login_frame, width=200, height=200, bg='white', highlightthickness=0, highlightbackground='white')
        user_logo.grid(row=0, column=0, pady=5)

        # Draw a circle on the user logo
        user_logo.create_oval(0, 0, 200, 200, fill='white',  outline='white')
        user_logo.create_image(100, 100, image=user_logo_img)

        # Create a Label widget for the username field
        username_label = ttk.Label(login_frame, text='Username:')
        username_label.grid(row=1, column=0, pady=5)

        # Create an Entry widget for the username field
        username_entry = ttk.Entry(login_frame)
        username_entry.grid(row=2, column=0, pady=5)

        # Create a Label widget for the password field
        password_label = ttk.Label(login_frame, text='Password:')
        password_label.grid(row=3, column=0, pady=5)

        # Create an Entry widget for the password field
        password_entry = ttk.Entry(login_frame, show='*')
        password_entry.grid(row=4, column=0, pady=5)

        # Create a Button widget for the login button
        login_button = tk.Button(login_frame, text='Login', bg='#1c72eb', fg='white', command=lambda: Login(root,username_entry,password_entry,login_status_label,login_frame,image_label))
        login_button.grid(row=5, column=0, pady=10)

        # Create a Label widget for the status field
        login_status_label = tk.Label(login_frame, bg="white")
        login_status_label.grid(row=6, column=0, pady=5)

        register_label = tk.Label(login_frame, text="New User Registeration !", fg="blue", bg="white", cursor="hand2")
        register_label.grid(row=7, column=0, pady=10)
        register_label.bind("<Button-1>", lambda event: register(root))



# set initial scale value and run the animation
label.scale = 0.1
animate()

root.mainloop()
