import tkinter as tk
from tkinter import *
import csv
import time

class RegistrationForm:
    def __init__(self,root):
        root.update()
        # root.destroy()
        root = tk.Toplevel()
        root.geometry('600x500')
        root.title('Registration Screen')
        root.configure(bg='white')
        # Create the header label
        header_label = Label(root, text="Register User", font=("Arial", 16), fg="black", bg="white")
        header_label.pack(pady=10)

        # Create the status label
        self.status_label = Label(root, text="", font=("Arial", 12), fg="black", bg="white")
        self.status_label.pack(pady=5)

        # Create the input labels and entry widgets
        username_label = Label(root, text="Username:", font=("Arial", 12), fg="black", bg="white")
        username_label.pack()
        self.username_entry = Entry(root, font=("Arial", 12))
        self.username_entry.pack(pady=5)

        password_label = Label(root, text="Password:", font=("Arial", 12), fg="black", bg="white")
        password_label.pack()
        self.password_entry = Entry(root, show="*", font=("Arial", 12))
        self.password_entry.pack(pady=5)

        confirm_password_label = Label(root, text="Confirm Password:", font=("Arial", 12), fg="black", bg="white")
        confirm_password_label.pack()
        self.confirm_password_entry = Entry(root, show="*", font=("Arial", 12))
        self.confirm_password_entry.pack(pady=5)

        name_label = Label(root, text="Name:", font=("Arial", 12), fg="black", bg="white")
        name_label.pack()
        self.name_entry = Entry(root, font=("Arial", 12))
        self.name_entry.pack(pady=5)

        number_label = Label(root, text="Number:", font=("Arial", 12), fg="black", bg="white")
        number_label.pack()
        self.number_entry = Entry(root, font=("Arial", 12))
        self.number_entry.pack(pady=5)

        location_label = Label(root, text="Location:", font=("Arial", 12), fg="black", bg="white")
        location_label.pack()
        self.location_entry = Entry(root, font=("Arial", 12))
        self.location_entry.pack(pady=5)

        # Create the register button
        register_button = Button(root, text="Register", font=("Arial", 12), fg="white", bg="#1c72eb", command=lambda: self.register_user(root))
        register_button.pack(pady=10)

        # Create close Button
        close_button = Button(root, text="Close", font=("Arial", 12), fg="white", bg="red", command=lambda: root.destroy())
        close_button.pack(pady=5)

        # Start the main event loop
        root.mainloop()


    def register_user(self,root):
        # Get the user input from the entry widgets
        username = self.username_entry.get()
        password = self.password_entry.get()
        confirm_password = self.confirm_password_entry.get()
        name = self.name_entry.get()
        number = self.number_entry.get()
        location = self.location_entry.get()

        # Validate the user input
        if not all([username, password, confirm_password, name, number, location]):
            self.status_label.config(text="Please fill all fields", fg="red")
            return
        if password != confirm_password:
            self.status_label.config(text="Passwords do not match", fg="red")
            return

        # Save the user input to a CSV file
        with open("users.csv", mode="a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([username, password, name, number, location])
        self.status_label.config(text="Registration successful", fg="green")




    