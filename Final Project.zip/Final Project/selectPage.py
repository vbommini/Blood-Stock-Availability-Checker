import tkinter as tk
from tkinter import ttk
from data.availability import bloodAvailability
from availabilityFrame import availabilityFrame
from PIL import Image,ImageTk

# load and resize image
image = Image.open("images/hands_blood.png")
width, height = image.size
new_width = 300
new_height = int((height / width) * new_width)
resized_image = image.resize((new_width, new_height))
tkimage = ImageTk.PhotoImage(resized_image)

class selectOptions:
    def __init__(self):
        self.location = ""
        self.bloodGroup = "SelectGroup"
    location:str
    bloodGroup:str
    def load(self,root,login_frame):
        login_frame.destroy()
        root.title("Check Availability")
        for widget in root.winfo_children():
            widget.destroy()

        # create label to display image
        label = tk.Label(root, image=tkimage,bg="white")
        label.pack(fill="both", expand=True)

        # hide the label
        label.place(relx=0.5, rely=0.5, anchor="center")
        label.lower()
        
        
        # create a dropdown menu for selecting a location
        def on_Location_select(event):
            selected_value = event.widget.get()
            self.location = selected_value
            global locatioN
            locatioN = self.location
            try:
                if bloodgrouP and locatioN:
                    availabilityFrame.load(root=root,frame=frame,location=self.location, bloodGroup=self.bloodGroup)
                    root.update()
            except:
                pass

        location_label = tk.Label(root, text="Select Place:",bg="red",fg="black", font=("Arial", 12))
        location_label.grid(row=0,column=1, padx=10, pady=10)
        location_options = ["Houghton", "Marquette", "Iron Mountain", "Appleton"]
        location_var = tk.StringVar(value=location_options[0])
        location_dropdown = ttk.Combobox(root, values=location_options, textvariable=location_var)
        location_dropdown.bind("<<ComboboxSelected>>", on_Location_select)
        location_dropdown.grid(row=0,column=2, padx=10, pady=10)

        # create a dropdown menu for selecting a blood group
        def on_Blood_select(event):
            selected_value = event.widget.get()
            self.bloodGroup = selected_value
            global bloodgrouP
            bloodgrouP=self.bloodGroup
            try:
                if bloodgrouP and locatioN:
                    availabilityFrame.load(root=root,frame=frame,location=self.location,bloodGroup=self.bloodGroup)
                    root.update()
                    print(f"Selected value: {selected_value}")
            except:
                pass
        blood_group_label = tk.Label(root, text="Select Blood Group:",bg="red",fg="black", font=("Arial", 12))
        blood_group_label.grid(row=0,column=3, padx=10, pady=10)
        blood_group_options = ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-", "SelectGroup"]
        blood_group_var = tk.StringVar(value=blood_group_options[0])
        blood_group_dropdown = ttk.Combobox(root, values=blood_group_options, textvariable=blood_group_var)
        blood_group_dropdown.bind("<<ComboboxSelected>>", on_Blood_select)
        blood_group_dropdown.grid(row=0,column=4, padx=10, pady=10)

        # create a frame with sunken and round corners
        # Create a style object
        style = ttk.Style()

        # Configure the style with a border of 1px and round corners
        style.configure('Custom.TFrame', borderwidth=.5, 
                        background='white', bordercolor='gray', 
                        highlightbackground='gray')
        
        style.configure('Custom.Label',background= "white")

        frame = ttk.Frame(root, style="Custom.TFrame")
        frame.grid(row=2, column=1, columnspan=4, padx=10, pady=10)


